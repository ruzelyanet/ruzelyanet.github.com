(function () {
    'use strict';

    angular.module('app.calendar', ['ui.calendar', 'ui.bootstrap']);

})();
